// ==UserScript==
// @name         High Court Catalogue Table Filter & Range Checkbox
// @namespace    Sajin M. Simon
// @version      2.1
// @description  Filter catalogue rows and Shift-click range select checkboxes (Enhanced Event Triggering)
// @author       Sajin M. Simon
// @match        *://10.145.22.38:3030/rkj-cataloguing/add-catalogue*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let rangeEnabled = true;
    let lastChecked = null;
    let observer = null;

    // --- HELPER FUNCTIONS ---
    function isMainCheckbox(cb) {
        // Exclude header checkboxes ("All", "Same for all") or TH inputs
        const parentCellText = cb.parentElement ? cb.parentElement.textContent.toLowerCase() : '';
        const nameAttr = (cb.name || '').toLowerCase();
        const idAttr = (cb.id || '').toLowerCase();

        if (parentCellText.includes('same for all') || parentCellText.includes('all') ||
            nameAttr.includes('same') || idAttr.includes('same') ||
            cb.closest('th')) {
            return false;
        }

        // Only target checkboxes in visible rows
        const row = cb.closest('tr');
        if (row && row.style.display === 'none') {
            return false;
        }

        return true;
    }

    // Safely trigger events to register state with Angular/JS frameworks
    function setCheckboxState(cb, targetState) {
        if (cb.checked !== targetState) {
            cb.checked = targetState;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
            cb.dispatchEvent(new Event('input', { bubbles: true }));
            cb.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        }
    }

    function createFilterAndRangeUI() {
        if (document.getElementById('custom-table-filter-ui')) return;

        // --- FILTER UI CONTAINER ---
        const container = document.createElement('div');
        container.id = 'custom-table-filter-ui';
        Object.assign(container.style, {
            position: 'fixed',
            bottom: '10px',
            right: '20px',
            zIndex: '9999',
            backgroundColor: '#ffffff',
            padding: '8px 12px',
            borderRadius: '8px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
            border: '1px solid #ddd',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontFamily: 'sans-serif',
            fontSize: '13px'
        });

        // Filter Label
        const label = document.createElement('label');
        label.textContent = 'Filter Approved By:';
        label.style.fontWeight = 'bold';

        // Filter Input
        const input = document.createElement('input');
        input.type = 'text';
        input.id = 'approved-by-filter-input';
        input.placeholder = 'e.g., WEEDU14 19-Sep-26';
        Object.assign(input.style, {
            padding: '6px 10px',
            border: '1px solid #ccc',
            borderRadius: '4px',
            outline: 'none',
            fontSize: '13px',
            width: '180px'
        });

        // Exact Match Checkbox
        const exactCheckboxLabel = document.createElement('label');
        exactCheckboxLabel.style.display = 'flex';
        exactCheckboxLabel.style.alignItems = 'center';
        exactCheckboxLabel.style.gap = '4px';
        exactCheckboxLabel.style.cursor = 'pointer';

        const exactCheckbox = document.createElement('input');
        exactCheckbox.type = 'checkbox';
        exactCheckbox.id = 'exact-match-checkbox';
        exactCheckbox.checked = true;

        exactCheckboxLabel.appendChild(exactCheckbox);
        exactCheckboxLabel.appendChild(document.createTextNode('Exact match'));

        // Visible Rows Count Badge
        const countBadge = document.createElement('span');
        countBadge.id = 'filter-count-badge';
        Object.assign(countBadge.style, {
            fontSize: '12px',
            color: '#555',
            marginLeft: '2px'
        });

        // Clear Filter Button
        const clearBtn = document.createElement('button');
        clearBtn.textContent = '✕';
        Object.assign(clearBtn.style, {
            border: 'none',
            background: '#f0f0f0',
            cursor: 'pointer',
            padding: '4px 8px',
            borderRadius: '4px',
            fontWeight: 'bold',
            color: '#666'
        });

        // --- CHECKBOX RANGE TOGGLE BUTTON ---
        const rangeToggleBtn = document.createElement('button');
        rangeToggleBtn.id = 'range-toggle-btn';
        rangeToggleBtn.innerHTML = 'Checkbox Range: <b>ON</b>';
        Object.assign(rangeToggleBtn.style, {
            border: 'none',
            backgroundColor: '#4CAF50',
            color: '#fff',
            padding: '6px 10px',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '12px',
            marginLeft: '6px',
            fontWeight: '500'
        });

        rangeToggleBtn.addEventListener('click', function() {
            rangeEnabled = !rangeEnabled;
            if (rangeEnabled) {
                rangeToggleBtn.innerHTML = 'Checkbox Range: <b>ON</b>';
                rangeToggleBtn.style.backgroundColor = '#4CAF50';
            } else {
                rangeToggleBtn.innerHTML = 'Checkbox Range: <b>OFF</b>';
                rangeToggleBtn.style.backgroundColor = '#f44336';
                lastChecked = null;
            }
        });

        // --- FILTER LOGIC ---
        function applyFilter() {
            if (observer) observer.disconnect();

            const query = input.value.trim().replace(/\s+/g, ' ').toUpperCase();
            const isExact = exactCheckbox.checked;
            const rows = document.querySelectorAll('table tbody tr');

            if (!rows.length) {
                reconnectObserver();
                return;
            }

            let visibleCount = 0;

            rows.forEach(row => {
                const cells = row.children;
                if (!cells.length) return;

                if (!query) {
                    row.style.display = '';
                    visibleCount++;
                    return;
                }

                // Column 7 (Index 6) is "Approved By"
                const cellText = (cells[6] ? cells[6].textContent : row.textContent)
                    .trim()
                    .replace(/\s+/g, ' ')
                    .toUpperCase();

                const codeMatch = cellText.match(/[A-Z0-9]+/i);
                const extractedCode = codeMatch ? codeMatch[0].toUpperCase() : cellText;

                let matches = false;
                if (isExact) {
                    matches = (cellText === query) || (extractedCode === query);
                } else {
                    matches = cellText.includes(query);
                }

                if (matches) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });

            countBadge.textContent = query ? `(${visibleCount} visible)` : '';
            reconnectObserver();
        }

        let debounceTimer;
        function debouncedApplyFilter() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(applyFilter, 150);
        }

        function reconnectObserver() {
            const table = document.querySelector('table');
            if (table && observer) {
                observer.observe(table, { childList: true, subtree: true });
            }
        }

        input.addEventListener('input', debouncedApplyFilter);
        exactCheckbox.addEventListener('change', applyFilter);
        clearBtn.addEventListener('click', () => {
            input.value = '';
            applyFilter();
            input.focus();
        });

        // Assemble UI
        container.appendChild(label);
        container.appendChild(input);
        container.appendChild(exactCheckboxLabel);
        container.appendChild(clearBtn);
        container.appendChild(countBadge);
        container.appendChild(rangeToggleBtn);

        document.body.appendChild(container);

        observer = new MutationObserver(() => {
            if (input.value.trim()) {
                debouncedApplyFilter();
            }
        });

        reconnectObserver();
    }

    // --- RANGE CHECKBOX EVENT HANDLER ---
    document.addEventListener('click', function(e) {
        if (!rangeEnabled) return;

        const target = e.target;

        if (target && target.type === 'checkbox' && isMainCheckbox(target)) {
            const checkboxes = Array.from(document.querySelectorAll('table tbody tr input[type="checkbox"]'))
                                    .filter(isMainCheckbox);

            if (lastChecked && (e.shiftKey || lastChecked !== target)) {
                let start = checkboxes.indexOf(target);
                let end = checkboxes.indexOf(lastChecked);

                if (start !== -1 && end !== -1) {
                    const sliceStart = Math.min(start, end);
                    const sliceEnd = Math.max(start, end);

                    const targetState = target.checked;
                    for (let i = sliceStart; i <= sliceEnd; i++) {
                        setCheckboxState(checkboxes[i], targetState);
                    }
                }
            }

            lastChecked = target;
        }
    });

    // Initialize UI
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createFilterAndRangeUI);
    } else {
        setTimeout(createFilterAndRangeUI, 1000);
    }
})();