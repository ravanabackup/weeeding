// ==UserScript==
// @name         Auto Select Checkbox Range with Exclusions
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Select initial and final checkbox to check/uncheck all main row checkboxes in between, ignoring header and "Same for all" checkboxes.
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isEnabled = true;
    let lastChecked = null;

    // Create floating toggle button
    const toggleBtn = document.createElement('button');
    toggleBtn.innerHTML = 'Checkbox Range: <b>ON</b>';
    Object.assign(toggleBtn.style, {
        position: 'fixed',
        top: '15px',
        right: '15px',
        zIndex: '999999',
        padding: '8px 12px',
        backgroundColor: '#4CAF50',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
        boxShadow: '0 2px 6px rgba(0,0,0,0.3)',
        fontSize: '13px',
        fontFamily: 'sans-serif'
    });

    // Toggle button click handler
    toggleBtn.addEventListener('click', function() {
        isEnabled = !isEnabled;
        if (isEnabled) {
            toggleBtn.innerHTML = 'Checkbox Range: <b>ON</b>';
            toggleBtn.style.backgroundColor = '#4CAF50';
        } else {
            toggleBtn.innerHTML = 'Checkbox Range: <b>OFF</b>';
            toggleBtn.style.backgroundColor = '#f44336';
            lastChecked = null;
        }
    });

    // Filter helper to exclude headers, "Select all", and "Same for all" checkboxes
    function isMainCheckbox(cb) {
        // Exclude checkboxes located inside table headers
        if (cb.closest('th')) return false;

        const parentCellText = cb.parentElement ? cb.parentElement.textContent.toLowerCase() : '';
        const nameAttr = (cb.name || '').toLowerCase();
        const idAttr = (cb.id || '').toLowerCase();

        // Exclude inputs with 'same for all', 'select all', or 'all'/'same' keywords
        if (parentCellText.includes('same for all') ||
            parentCellText.includes('select all') ||
            parentCellText.includes('all') ||
            nameAttr.includes('same') ||
            idAttr.includes('same') ||
            nameAttr.includes('all') ||
            idAttr.includes('all')) {
            return false;
        }
        return true;
    }

    document.body.appendChild(toggleBtn);

    // Global click listener to track checkbox range selection
    document.addEventListener('click', function(e) {
        if (!isEnabled) return;

        const target = e.target;

        if (target && target.type === 'checkbox' && isMainCheckbox(target)) {
            // Get all eligible checkboxes on the page
            const checkboxes = Array.from(document.querySelectorAll('input[type="checkbox"]'))
                                    .filter(isMainCheckbox);

            if (lastChecked && (e.shiftKey || lastChecked !== target)) {
                const start = checkboxes.indexOf(target);
                const end = checkboxes.indexOf(lastChecked);

                if (start !== -1 && end !== -1) {
                    const sliceStart = Math.min(start, end);
                    const sliceEnd = Math.max(start, end);
                    const targetState = target.checked; // Match the state of the 2nd clicked checkbox

                    for (let i = sliceStart; i <= sliceEnd; i++) {
                        const currentCheckbox = checkboxes[i];
                        if (currentCheckbox.checked !== targetState) {
                            currentCheckbox.checked = targetState;

                            // Trigger dynamic page listeners (Angular, React, jQuery, etc.)
                            currentCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
                            currentCheckbox.dispatchEvent(new Event('click', { bubbles: true }));
                        }
                    }
                }
            }

            lastChecked = target;
        }
    });
})();