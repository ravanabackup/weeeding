// ==UserScript==
// @name         High Court Auto-fill and Checkbox Counter
// @namespace    Sajin M. Simon
// @version      1.3
// @description  Adds auto-fill functionality with heart button and checkbox counter
// @author       Sajin M. Simon
// @match        *://10.145.22.38:3030/rkj-cataloguing/add-catalogue*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // State management
    const state = {
        batchNo: '',
        rackNo: '',
        shelfNo: '',
        isDataLoaded: false,
        selectedCount: 0
    };

    // Helper function to check if a checkbox belongs to the table records
    function isRecordCheckbox(cb) {
        return cb.type === 'checkbox' && !cb.id?.includes('all') && cb.closest('tr');
    }

    // Safely update input values and notify reactive framework state listeners (React/Angular/Vue)
    function setInputValue(input, newValue) {
        if (!input || newValue === undefined || newValue === '') return;

        // Skip if input already has a value set to avoid triggering unnecessary reset cycles
        if (input.value === newValue) return;

        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeInputValueSetter) {
            nativeInputValueSetter.call(input, newValue);
        } else {
            input.value = newValue;
        }

        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Create floating control button
    function createHeartButton() {
        const heartButton = document.createElement('span');
        Object.assign(heartButton.style, {
            fontSize: '14px',
            fontWeight: 'bold',
            cursor: 'pointer',
            position: 'fixed',
            bottom: '10px',
            left: '10px',
            zIndex: '9999',
            transition: 'all 0.3s ease',
            padding: '8px 12px',
            borderRadius: '20px',
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
            textAlign: 'center',
            border: '1px solid #ccc',
            userSelect: 'none'
        });

        updateHeartButtonState(heartButton);

        heartButton.addEventListener('mouseover', () => {
            heartButton.style.transform = 'scale(1.05)';
        });

        heartButton.addEventListener('mouseout', () => {
            heartButton.style.transform = 'scale(1)';
        });

        heartButton.addEventListener('click', async () => {
            if (await promptForValues()) {
                fillAllCheckedRows();
            }
        });

        return heartButton;
    }

    function updateHeartButtonState(heartButton) {
        const currentState = state.isDataLoaded ?
            { symbol: '⚙️ Set Data (Active)', color: '#2e7d32' } :
            { symbol: '⚙️ Set Data (Empty)', color: '#333333' };
        heartButton.innerHTML = currentState.symbol;
        heartButton.style.color = currentState.color;
    }

    // Fill all currently checked rows
    function fillAllCheckedRows() {
        const checkedBoxes = Array.from(document.querySelectorAll('tbody input[type="checkbox"]:checked, table input[type="checkbox"]:checked'))
            .filter(isRecordCheckbox);

        checkedBoxes.forEach(checkbox => {
            fillRowValues(checkbox.closest('tr'));
        });
    }

    // Fill specific row values without touching or resetting existing ones unnecessarily
    function fillRowValues(row) {
        if (!row) return;

        const batchInput = row.querySelector('input[placeholder*="Batch" i], input[id^="batch_"]');
        const rackInput = row.querySelector('input[placeholder*="Rack" i], input[id^="rack_"]');
        const shelfInput = row.querySelector('input[placeholder*="Shelf" i], input[id^="shelf_"]');

        setInputValue(batchInput, state.batchNo);
        setInputValue(rackInput, state.rackNo);
        setInputValue(shelfInput, state.shelfNo);

        // Select 'CJA' in location dropdown if present
        const locationDropdown = row.querySelector('select');
        if (locationDropdown) {
            const cjaOption = Array.from(locationDropdown.options)
                .find(option => option.text.trim().toUpperCase() === 'CJA');

            if (cjaOption && locationDropdown.value !== cjaOption.value) {
                locationDropdown.value = cjaOption.value;
                locationDropdown.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }
    }

    async function promptForValues() {
        const prompts = [
            { field: 'batchNo', message: 'Please enter Batch number:' },
            { field: 'rackNo', message: 'Please enter Rack number:' },
            { field: 'shelfNo', message: 'Please enter Shelf number:' }
        ];

        for (const prompt of prompts) {
            const value = window.prompt(prompt.message, state[prompt.field]);
            if (value === null) return false;
            state[prompt.field] = value;
        }

        const isReset = prompts.every(prompt =>
            state[prompt.field] === '0' || state[prompt.field].trim() === ''
        );

        if (isReset) {
            state.batchNo = '';
            state.rackNo = '';
            state.shelfNo = '';
            state.isDataLoaded = false;
        } else {
            state.isDataLoaded = true;
        }

        const heartButton = document.getElementById('autofillStateBtn');
        if (heartButton) {
            updateHeartButtonState(heartButton);
        }
        return !isReset;
    }

    // Checkbox counter functionality
    function createCounter() {
        const counter = document.createElement('div');
        counter.id = 'selectionCounter';
        Object.assign(counter.style, {
            position: 'fixed',
            bottom: '50px',
            left: '10px',
            zIndex: '9999',
            padding: '6px 12px',
            background: 'white',
            border: '1px solid #ccc',
            borderRadius: '4px',
            fontWeight: 'bold',
            fontSize: '13px',
            minWidth: '90px',
            textAlign: 'center',
            boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
        });
        document.body.appendChild(counter);
        updateCounter();
    }

    function updateCounter() {
        const checkedBoxes = Array.from(document.querySelectorAll('tbody input[type="checkbox"]:checked, table input[type="checkbox"]:checked'))
            .filter(isRecordCheckbox);

        state.selectedCount = checkedBoxes.length;

        const counter = document.getElementById('selectionCounter');
        if (counter) {
            counter.textContent = `Selected: ${state.selectedCount}`;
            counter.style.backgroundColor = state.selectedCount > 0 ? '#e8f5e9' : 'rgba(255,255,255,0.95)';
            counter.style.color = state.selectedCount > 0 ? '#2e7d32' : '#34495e';
        }
    }

    // Row highlighting
    function updateRowHighlight(checkbox) {
        const row = checkbox.closest('tr');
        if (!row) return;

        if (checkbox.checked) {
            Object.assign(row.style, {
                backgroundColor: '#b5eeff',
                transition: 'background-color 0.2s ease'
            });
        } else {
            Object.assign(row.style, {
                backgroundColor: '',
                transition: 'background-color 0.2s ease'
            });
        }
    }

    // Initialize script components
    function initialize() {
        const btn = createHeartButton();
        btn.id = 'autofillStateBtn';
        document.body.appendChild(btn);
        createCounter();

        // Event listener for checking/unchecking boxes dynamically
        document.addEventListener('change', (e) => {
            if (e.target.type === 'checkbox') {
                updateCounter();
                updateRowHighlight(e.target);

                if (state.isDataLoaded && e.target.checked && isRecordCheckbox(e.target)) {
                    fillRowValues(e.target.closest('tr'));
                }
            }
        });

        // DOM Mutation Observer for dynamic table contents
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) {
                            const checkboxes = node.querySelectorAll('input[type="checkbox"]');
                            checkboxes.forEach(cb => {
                                updateRowHighlight(cb);
                            });
                        }
                    });
                }
            });
        });

        observer.observe(document.body, {
            subtree: true,
            childList: true
        });
    }

    // Run initialization
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
})();